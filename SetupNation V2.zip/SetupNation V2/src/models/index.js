// índice de datos que voy a exportar
module.exports = {
    // index llama a img
Image: require("./image"),
};