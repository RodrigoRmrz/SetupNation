export * as authCtrl from "./auth.controller.js";
export * as imageCtrl from "./image.controller.js";
export * as homeCtrl from "./home.controller.js";
