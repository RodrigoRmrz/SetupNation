module.exports = {
 database: {
    URI: 'mongodb://localhost/SetupNation'
 }
 // google{}
}